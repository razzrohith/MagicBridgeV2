# magicbridge-marketplace — Raj's personal Claude Code marketplace

A tiny Claude Code marketplace holding the **magicbridge-toolkit** plugin: reusable skills +
connectors that turn your repeat MagicBridge workflows into one-command agent actions, and that
travel with you so a rebuilt VM is one install away from your whole setup.

## What's inside
```
magicbridge-marketplace/
├── .claude-plugin/marketplace.json     # the marketplace registry
└── plugins/
    └── magicbridge-toolkit/            # the plugin
        ├── .claude-plugin/plugin.json
        ├── .mcp.json                   # GitHub + filesystem connectors
        ├── commands/                   # /deploy  /push  /pi-status
        └── skills/                     # magicbridge-brief, deploy-to-pi,
                                        # sync-and-push, find-pi, serial-recover
```

## One-time machine prep (on your Windows VM)
1. `pip install paramiko pyserial`   (the deploy/serial/find scripts use them)
2. Install Node.js  (the MCP connectors run via `npx`)
3. Create a GitHub token (github.com → Settings → Developer settings → fine-grained token, repo
   scope) and set it as an env var so the GitHub connector can use it:
   ```
   setx GITHUB_PERSONAL_ACCESS_TOKEN "ghp_xxx"
   ```
   (reopen the terminal after `setx`). Edit the `C:\dev` path in `.mcp.json` to your projects root.

## How to give it to Claude Code — two ways

### A) Persistent install (recommended)
Put this whole folder somewhere permanent, e.g. `C:\dev\magicbridge-marketplace`
(optionally `git init` + push it to a private GitHub repo). Then, inside Claude Code:
```
/plugin marketplace add C:\dev\magicbridge-marketplace
/plugin install magicbridge-toolkit@magicbridge-marketplace
```
(Or from a repo: `/plugin marketplace add razzrohith/magicbridge-marketplace`.)
It's now available in every future session on that machine.

### B) Load for one session (quick test)
```
claude --plugin-dir C:\dev\magicbridge-marketplace\plugins\magicbridge-toolkit
```

Verify with `/plugin` (see it enabled) and `/help` (see the `/deploy`, `/push`, `/pi-status`
commands). Check connectors with `/mcp`.

## How to invoke / use it, and for what

**Skills trigger automatically** when your request matches their description — you usually don't
call them by name. Examples of what to say and which skill fires:

| You say… | Skill that fires | What it does |
|----------|------------------|--------------|
| "let's work on MagicBridge" / "open the KVM project" | `magicbridge-brief` | reads the brain (history, gotchas, live tasks) before doing anything |
| "deploy this to the pi" / "update the device" | `deploy-to-pi` | rw → SFTP → relock → restart → verify, safely |
| "commit and push" / "save this to git" | `sync-and-push` | mirrors to E:\, pushes to GitHub, aligns the Pi, updates the tracker |
| "I can't reach the pi" / "its IP changed" | `find-pi` | scans the subnet for the device |
| "the pi has no network" / "connect over serial" | `serial-recover` | rescues it via the COM8 serial console |

**Slash commands** are explicit shortcuts you type: `/deploy`, `/push "commit message"`,
`/pi-status`.

**Connectors** are used by the agent as tools: the **github** connector for issues/PRs/repo
ops, the **filesystem** connector for scoped file access across your projects.

## Making it truly portable
Keep this marketplace in its own git repo. On any new/rebuilt VM: `pip install paramiko
pyserial`, install Node, set the GitHub token, then `/plugin marketplace add <your repo>` +
`/plugin install magicbridge-toolkit@magicbridge-marketplace`. Done — your whole workflow is back.

## Extending it
Add a new skill = a new folder under `plugins/magicbridge-toolkit/skills/<name>/SKILL.md` (with
`name` + `description` frontmatter — the description is what makes it auto-trigger). Bump the
`version` in both `plugin.json` and the marketplace entry, commit, and re-run `/plugin install`.
Use the same pattern to spin up a **second** plugin for a future project inside this same
marketplace (add it to the `plugins` array in `marketplace.json`).
