---
description: Deploy the file(s) I just changed to the MagicBridge Pi the safe way, then verify.
---
Deploy my recent MagicBridge change to the Pi using the `deploy-to-pi` skill:
unlock the read-only rootfs, SFTP the file, chmod, relock, restart the affected service,
syntax-check, curl the endpoint, and confirm the rootfs is back to read-only.
If you don't know the Pi's current IP, use the `find-pi` skill first.
Arguments (optional): $ARGUMENTS
