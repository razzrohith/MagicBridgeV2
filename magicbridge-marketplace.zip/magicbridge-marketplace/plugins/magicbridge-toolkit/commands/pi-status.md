---
description: Check the MagicBridge Pi — services, pages, WiFi, and identity.
---
SSH the MagicBridge Pi and report: `systemctl is-active kvmd kvmd-nginx magicbridge-net
magicbridge-stealth kvmd-otg`; the HTTP codes for /login/ /mb/ui/ /stealth/; WiFi signal + IP;
the live USB gadget identity + monitor serial (confirm NO "CAFEBABE"); and that the rootfs is
read-only. If unreachable, fall back to the `find-pi` then `serial-recover` skills.
