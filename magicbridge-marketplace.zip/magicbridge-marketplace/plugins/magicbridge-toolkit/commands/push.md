---
description: Commit + push MagicBridge changes to GitHub and align the Pi.
---
Use the `sync-and-push` skill: run sync_and_push.py with a clear commit message summarizing what
changed, confirm push rc=0 and the new commit hash, then (if the Pi is online) align it.
Finally update TASK_TRACKER.md (move the finished item to Done with the commit hash).
Commit message (optional): $ARGUMENTS
