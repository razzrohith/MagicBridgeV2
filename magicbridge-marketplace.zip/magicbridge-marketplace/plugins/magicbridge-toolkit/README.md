# magicbridge-toolkit (Claude Code plugin)

Reusable Claude Code skills + connectors for the MagicBridge KVM project (PiKVM V4 Mini).

## Skills (auto-trigger on matching tasks, or invoke by name)
| Skill | What it does |
|-------|--------------|
| `magicbridge-brief` | Loads the project brain (history, gotchas, current tasks) before any work |
| `deploy-to-pi` | Safe deploy of a file to the Pi (rw → SFTP → relock → restart → verify) |
| `sync-and-push` | Commit + push local→E:→GitHub, align the Pi, update the tracker |
| `find-pi` | Locate the Pi's current IP after it changed networks |
| `serial-recover` | Rescue the Pi over the COM8 serial console when it has no network |

## Slash commands
`/deploy`, `/push`, `/pi-status`

## Connectors (MCP) — in `.mcp.json`
- **filesystem** — scoped file access under `C:\dev` (edit the path in `.mcp.json`).
- **github** — repo/issue/PR access. Set `GITHUB_PERSONAL_ACCESS_TOKEN` in your environment
  (create a token at github.com → Settings → Developer settings → fine-grained token, repo scope).

## Requirements on the machine
- `pip install paramiko pyserial`  (the helper scripts use them)
- Node.js (for the `npx` MCP servers)

## Install
See the marketplace README one level up, or:
- Quick (one session):  `claude --plugin-dir <path-to>/plugins/magicbridge-toolkit`
- Persistent: add the marketplace, then `/plugin install magicbridge-toolkit@magicbridge-marketplace`
