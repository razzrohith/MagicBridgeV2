#!/usr/bin/env python3
"""serial_lib.py — pyserial wrapper for the MagicBridge Pi serial console (COM8, 115200).
Needs `pip install pyserial`. Login root/root (fallback raj/lol). run(cmd) wraps commands in
markers and returns clean output."""
import time, re
try:
    import serial
except ImportError:
    raise SystemExit("pip install pyserial")

PORT = "COM8"; BAUD = 115200

class Pi:
    def __init__(self, port=PORT, baud=BAUD):
        self.s = serial.Serial(port, baud, timeout=1)
    def _read(self, secs=2.0):
        end = time.time() + secs; buf = b""
        while time.time() < end:
            n = self.s.in_waiting
            if n: buf += self.s.read(n); end = time.time() + 0.6
            else: time.sleep(0.05)
        return buf.decode(errors="replace")
    def _w(self, line): self.s.write((line + "\n").encode()); time.sleep(0.2)
    def login(self, users=(("root","root"),("raj","lol"))):
        self._w(""); self._read(1.5)
        for u,p in users:
            self._w(u); self._read(1.0); self._w(p); out = self._read(2.0)
            self._w(""); out += self._read(1.0)
            if "]#" in out or "]$" in out or "$" in out.strip()[-3:]:
                return "logged in as %s" % u
        return "login uncertain (check prompt)"
    @staticmethod
    def _clean(t):
        t = re.sub(r"\x1b\][0-9;]*;?[^\x07\x1b]*(\x07|\x1b\\)", "", t)  # OSC
        t = re.sub(r"\x1b\[[0-9;?]*[A-Za-z]", "", t)                    # CSI
        t = t.replace("\x1b[?2004h","").replace("\x1b[?2004l","")       # bracketed paste
        return t
    def run(self, cmd, timeout=12):
        self._w("echo MB_S_T_A_R_T; %s; echo MB_E_N_D_$?" % cmd)
        end = time.time() + timeout; buf = ""
        while time.time() < end:
            buf += self._clean(self._read(0.8))
            if "MB_E_N_D_" in buf: break
        m = re.search(r"MB_S_T_A_R_T\s*(.*?)\s*MB_E_N_D_", buf, re.S)
        return (m.group(1).strip() if m else buf.strip())
    def close(self):
        try: self.s.close()
        except Exception: pass
