---
name: serial-recover
description: Rescue the MagicBridge Pi over the USB serial console (COM8) when it has NO network — find out why WiFi is down and connect it. Use when the user says the Pi is "unreachable", "not on the network", "won't connect to wifi", "I moved to a new place", "connect over serial", "the ioioi/serial port", or when SSH to the Pi times out everywhere.
version: 1.0.0
---

# Serial recovery of the MagicBridge Pi

When the Pi has no network (new location, wrong WiFi, failed AP), the **serial console** is the
way in. The V4 Mini's IOIOI port is a USB serial console (CP210x), it appears as **COM8** at
**115200** baud on the laptop. Login `root`/`root` (fallback `raj`/`lol`).

## Use the bundled helper
`serial_lib.py` (shipped with this skill) is a pyserial wrapper. Import it in a small script:
```python
from serial_lib import Pi
pi = Pi(); pi.login()
print(pi.run("ip -4 addr show wlan0 | grep inet || echo NO-IP"))
```
Run scripts on the laptop; they write their own `*_log.txt`.

## Manual WiFi connect over serial (AP idle, you know the creds)
```
pkill hostapd; pkill dnsmasq
ip link set wlan0 down; iw dev wlan0 set type managed; ip link set wlan0 up
systemctl restart wpa_supplicant@wlan0; systemctl restart systemd-networkd
```
Associates + DHCP in ~15s. To SAVE new creds, write a plain-quoted psk block to
`/etc/wpa_supplicant/wpa_supplicant-wlan0.conf` (after `command rw`) — **never `wpa_passphrase`**
(it silently fails on SSIDs with spaces) — then reboot to connect cleanly.

## Serial gotchas
- A backgrounded `reboot &` gets SIGHUP'd when the session closes and never fires. Reboot
  synchronously (accept the serial drop) or use `systemd-run --on-active=3 systemctl reboot`.
- `printf '%s' "a\nb"` does NOT expand `\n` — put escapes in the FORMAT string: `printf 'a\nb\n'`.
- Only one OS can own COM8 — release it from any PuTTY/other session first. In a VMware guest,
  pass the CP210x USB device through to the VM.
