#!/usr/bin/env python3
"""
deploy_to_pi.py — safe deploy of one file to the MagicBridge Pi (read-only rootfs aware).

Usage (run on the Windows laptop; needs `pip install paramiko`):
    python deploy_to_pi.py --host 192.168.1.37 \
        --local "C:\\dev\\magicbridge\\services\\magicbridge-net\\app.py" \
        --remote "/opt/magicbridge/services/magicbridge-net/app.py" \
        --service magicbridge-net
Reads/writes deploy_to_pi_log.txt next to this script. Never shell-redirect its output.
"""
import argparse, os, sys

LOG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "deploy_to_pi_log.txt")
def log(m): open(LOG, "a", encoding="utf-8").write(str(m) + "\n"); print(m)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", required=True)
    ap.add_argument("--user", default="root")
    ap.add_argument("--password", default="root")
    ap.add_argument("--local", required=True)
    ap.add_argument("--remote", required=True)
    ap.add_argument("--service", default="", help="systemd service to restart after (optional)")
    ap.add_argument("--reload-nginx", action="store_true", help="reload kvmd-nginx after")
    a = ap.parse_args()
    open(LOG, "w").close()

    import paramiko
    cli = paramiko.SSHClient(); cli.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    cli.connect(a.host, username=a.user, password=a.password, timeout=15,
                allow_agent=False, look_for_keys=False)

    def run(cmd, t=30):
        ch = cli.get_transport().open_session(); ch.settimeout(t); ch.exec_command(cmd)
        out = b""
        while True:
            d = ch.recv(65535)
            if not d: break
            out += d
        return out.decode(errors="replace").strip()

    if not os.path.isfile(a.local):
        log("ERROR: local file not found: " + a.local); sys.exit(1)

    run("command rw 2>/dev/null || mount -o remount,rw /")          # 1. unlock
    sftp = cli.open_sftp()
    sftp.put(a.local, a.remote); sftp.chmod(a.remote, 0o644)        # 2-3. SFTP + chmod
    match = os.path.getsize(a.local) == sftp.stat(a.remote).st_size
    sftp.close()
    run("command ro 2>/dev/null || true")                           # 4. relock
    log("deploy %s -> %s : %s" % (a.local, a.remote, "OK" if match else "SIZE MISMATCH"))

    if a.remote.endswith(".py"):                                    # 6. syntax verify
        chk = run("python3 -c \"compile(open('%s').read(),'x','exec')\" 2>&1 && echo CLEAN" % a.remote)
        log("syntax: " + (chk or "(no output)"))
        if "CLEAN" not in chk:
            log("ABORT: syntax error, not restarting"); cli.close(); sys.exit(2)

    if a.service:                                                   # 5. restart
        log("restart %s: %s" % (a.service, run("systemctl restart %s && sleep 1 && systemctl is-active %s" % (a.service, a.service))))
    if a.reload_nginx:
        log("nginx reload: " + run("systemctl reload kvmd-nginx 2>&1 && echo OK"))

    log("rootfs state: " + run("mount | grep 'on / ' | grep -oE 'ro,|rw,'"))  # confirm relocked
    cli.close(); log("=== done ===")

if __name__ == "__main__":
    main()
