---
name: deploy-to-pi
description: Deploy a changed file to the MagicBridge Pi over SSH/SFTP the safe way — unlock the read-only rootfs, SFTP the file, relock, restart the service, and verify. Use whenever the user says "deploy to the pi", "push this to magicbridge", "update the pi", "send this file to the device", or after editing any file under /opt/magicbridge or /etc/kvmd on the MagicBridge/PiKVM device.
version: 1.0.0
---

# Deploy to the MagicBridge Pi

The MagicBridge Pi (PiKVM V4 Mini) has a **read-only root filesystem**. Any write silently
fails unless you unlock it first. This skill encodes the proven, safe deploy runbook.

## The golden sequence (never skip a step)
1. **Unlock** the rootfs: `command rw 2>/dev/null || mount -o remount,rw /`
2. **SFTP** the file (never base64-echo large files — buffer truncation corrupts them).
3. **chmod 644** the remote file.
4. **Relock**: `command ro 2>/dev/null || true`
5. **Restart** the affected service (`magicbridge-net`, `magicbridge-stealth`, or reload
   `kvmd-nginx` for nginx config).
6. **Verify**: syntax-check python with `python3 -c "compile(open('f').read(),'f','exec')"`
   (NOT `py_compile` — it false-fails writing `__pycache__` on the RO rootfs), confirm the
   service is `active`, curl the affected endpoint, and confirm the rootfs relocked (`mount |
   grep 'on / '` shows `ro,`).

## How to run it
A ready-made parametrized script ships with this skill. Run it from the Windows laptop:

```
python "${CLAUDE_PLUGIN_ROOT}/skills/deploy-to-pi/deploy_to_pi.py" \
    --host <PI_IP> --local "<C:\\path\\to\\file>" \
    --remote "/opt/magicbridge/services/magicbridge-net/app.py" \
    --service magicbridge-net
```
Then read `deploy_to_pi_log.txt` next to the script for the result. Update `--host` to the
Pi's current IP (it changes per location — use the `find-pi` skill if unknown).

## Critical gotchas (from the debug journal)
- **Never name a shell helper `rw`/`ro`** — a function named `rw` recurses into itself and
  crashes. The device already has `/usr/bin/rw`; call `command rw`.
- **`systemctl enable` fails EROFS even after `rw`** — to persist a unit across boot, create
  the `…/multi-user.target.wants/<unit>.service` symlink with `os.symlink()` and use plain
  `systemctl start`/`stop`.
- **Also commit to git.** `align_pi.py` only resets `/opt/magicbridge`; files under `/etc/kvmd`
  must be SFTP'd live. After deploying, run the `sync-and-push` skill so git isn't left behind.
- Confirm the rootfs is back to `ro` at the end — leaving it `rw` risks corruption on power loss.
