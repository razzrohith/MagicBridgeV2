#!/usr/bin/env python3
"""find_pi.py — scan a /24 for the MagicBridge Pi by trying SSH login. `pip install paramiko`.
Usage: python find_pi.py --subnet 192.168.1"""
import argparse, os, socket, concurrent.futures as cf
LOG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "find_pi_log.txt")
def log(m): open(LOG, "a", encoding="utf-8").write(str(m) + "\n"); print(m)

def probe(ip):
    import paramiko
    try:
        s = socket.create_connection((ip, 22), timeout=0.6); s.close()
    except Exception:
        return None
    for u, p in (("root", "root"), ("raj", "lol")):
        try:
            c = paramiko.SSHClient(); c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            c.connect(ip, username=u, password=p, timeout=4, allow_agent=False, look_for_keys=False)
            ch = c.get_transport().open_session(); ch.settimeout(6)
            ch.exec_command("hostname; systemctl is-active kvmd 2>/dev/null")
            out = ch.recv(4096).decode(errors="replace"); c.close()
            if "magicbridge" in out or "active" in out:
                return (ip, u, out.strip().replace("\n", " / "))
        except Exception:
            continue
    return None

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--subnet", required=True); a = ap.parse_args()
    open(LOG, "w").close(); log("scanning %s.0/24 for the Pi ..." % a.subnet)
    hits = []
    with cf.ThreadPoolExecutor(max_workers=64) as ex:
        for r in ex.map(probe, ["%s.%d" % (a.subnet, i) for i in range(1, 255)]):
            if r: hits.append(r); log("  FOUND %s (login %s) — %s" % r)
    log("done — %d candidate(s)" % len(hits) if hits else "no Pi found on this subnet")

if __name__ == "__main__":
    main()
