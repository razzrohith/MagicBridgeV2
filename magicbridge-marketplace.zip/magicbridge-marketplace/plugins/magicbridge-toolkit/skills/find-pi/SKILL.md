---
name: find-pi
description: Find the MagicBridge Pi's current IP address after it moved networks. Use when the user says "the pi's IP changed", "I can't reach the pi", "find the pi", "what's the pi's address now", or before deploying when the IP is unknown.
version: 1.0.0
---

# Find the MagicBridge Pi on the network

The Pi's IP changes every time it joins a new network. Ways to locate it, in order:
1. **mDNS** — open `https://magicbridge.local/` in a browser (browsers have mDNS; the Windows
   OS resolver does not, so raw sockets to `magicbridge.local` fail — that's expected).
2. **OLED** — the front-panel screen shows the IP.
3. **Scan the /24** — run the bundled `find_pi.py` (SSH-probes a subnet for the Pi's login).
4. **Serial console** — if it has no network at all, use the `serial-recover` skill and read
   `ip -4 addr show wlan0`.

## Run the scanner
```
python "${CLAUDE_PLUGIN_ROOT}/skills/find-pi/find_pi.py" --subnet 192.168.1
```
It tries SSH (root/root, raj/lol) across .1–.254 and reports which host answers as the Pi.
Then update your deploy scripts / the `--host` you pass to `deploy-to-pi`.
