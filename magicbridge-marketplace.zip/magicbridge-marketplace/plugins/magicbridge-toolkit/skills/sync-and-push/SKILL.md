---
name: sync-and-push
description: Commit and push MagicBridge changes so local, git, and the Pi never drift. Mirrors the build folder into the E:\ git repo, commits, pushes to GitHub, then (optionally) aligns the Pi. Use whenever the user says "commit", "push", "push to github", "save this to git", "sync the repo", or after finishing any MagicBridge change.
version: 1.0.0
---

# Keep local + git + Pi in sync

Standing rule: after ANY MagicBridge change, commit + push, and align the Pi — never leave an
edit only SFTP'd. Three places hold code:
1. **Edit folder** (Cowork-mounted): `C:\Users\razzr\Claude\Projects\MagicBridge\MagicBridgeV2\`
   — **not a git repo.**
2. **Git repo**: `E:\Startup\MagicbridgeV2\` → github.com/razzrohith/MagicBridgeV2 (`main`).
3. **Pi**: `/opt/magicbridge` (git tree) + `/etc/kvmd` (NOT in the git tree — SFTP those live).

## How
Run the project's own `sync_and_push.py` from the File Explorer address bar (or a terminal):
```
python "C:\Users\razzr\Claude\Projects\MagicBridge\MagicBridgeV2\sync_and_push.py" "clear commit message"
```
It robocopies the build folder → `E:\` (excluding logs/one-off scripts), then git add/commit/push.
Read `sync_and_push_log.txt` and confirm `git push rc=0` + the new commit hash.

Then, when the Pi is online, align its git tree:
```
python "C:\Users\razzr\Claude\Projects\MagicBridge\MagicBridgeV2\align_pi.py"
```
(`align_pi.py` only resets `/opt/magicbridge` — files under `/etc/kvmd` you must SFTP live via
the `deploy-to-pi` skill.)

## After pushing
Update `TASK_TRACKER.md`: move the finished item to Done **with the commit hash**, and update
the "Repo HEAD" line at the top. If you learned something non-obvious, add it to
`brain/05_DEBUG_JOURNAL.md` or `brain/07_GOTCHAS_CHEATSHEET.md`.
