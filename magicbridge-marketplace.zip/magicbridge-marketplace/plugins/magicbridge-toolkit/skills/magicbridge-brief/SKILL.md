---
name: magicbridge-brief
description: Load the MagicBridge project brain before doing any work on it. Use at the START of any MagicBridge task, or when the user mentions MagicBridge, the KVM, the PiKVM, the stealth panel, or the Pi. Ensures you read the history, gotchas, and current task state first, and keep the tracker updated.
version: 1.0.0
---

# MagicBridge project brief — read before touching anything

Before doing ANY MagicBridge work, read these files in the project repo (they are the source of
truth; do not rely on memory):
1. `START_HERE.md` — the index + mental model.
2. `TASK_TRACKER.md` — what's done, pending, and broken **right now**. Keep it updated as you work.
3. `brain/05_DEBUG_JOURNAL.md` + `brain/07_GOTCHAS_CHEATSHEET.md` — every past bug + trap.
   **Read these before debugging** — most "new" bugs are the read-only rootfs biting again.
4. `brain/02_HARDWARE_AND_ACCESS.md` + `brain/06_DEPLOY_RUNBOOK.md` — how to reach + deploy.
5. Skim `brain/01`, `brain/03`, `brain/04` for context.

## The non-negotiables
- The Pi's rootfs is **read-only** — unlock with `command rw` before any write, relock with
  `command ro`. Never name a shell helper `rw`/`ro` (infinite recursion).
- **Anonymity is the product**: no `CAFEBABE` serials, no visible PiKVM/Raspberry-Pi/kvmd tells,
  realistic USB/monitor identities only. Main page = view-only; editing lives on `/stealth/`.
- Never use `wpa_passphrase` (fails on SSIDs with spaces) — write a plain quoted psk.
- After every change: use the `sync-and-push` skill, then `deploy-to-pi`, then update `TASK_TRACKER.md`.
- Dependency-free frontend (no CDN). Realistic, codebase-grounded features — not generic checklist items.

## Related skills in this plugin
`deploy-to-pi` (safe deploy), `sync-and-push` (git), `find-pi` (locate the device),
`serial-recover` (rescue with no network).
